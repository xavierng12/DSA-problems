import java.util.ArrayList;


public class quizQueue {

	public static void main(String[] args) {
		ArrayList<Int> qOfsqNums;
		qOfsqNums.enqueue(1);
		int x;
		int count=1;
		do{count=count+1;
		x =(int)qOfSqNums.dequeue();
		qOfSqNums.enqueue(2*x);
		qOfSqNums.enqueue(4*x);
		}while(x!=4);
	}

}


public class demo {
int j =0;
int[]data = new int [10];
System.out.print(data[j]);
}

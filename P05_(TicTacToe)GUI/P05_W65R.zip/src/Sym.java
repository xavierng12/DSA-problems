
public enum Sym {
	X,O,E
}
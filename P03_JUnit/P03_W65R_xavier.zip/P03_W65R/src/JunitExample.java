
public class JunitExample {
	public int add(int a, int b) {
		int c;
		c = a+b;
		
		return c;
}	
	
	public int sub(int a, int b) {
		int c;
		c = a-b;
		
		return c;
		
}
	public int multiply(int a, int b) {
		int c;
		c = a*b;
		
		return c;
}
	public int divide(int a, int b) {
		int c;
		c = a/b;
		
		return c;
}
}
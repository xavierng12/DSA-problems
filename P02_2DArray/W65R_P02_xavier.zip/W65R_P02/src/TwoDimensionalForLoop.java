public class TwoDimensionalForLoop {
	public static void main(String args[]) {
		for (int i = 0; i < 3; i++) {
			for (int j = 2; j < 4; j++) {
				System.out.print(" i = " + i + " , " + " j =  " + j);
			}
			System.out.println();
		}
	}
 }


public class workSheet {
	public static void main(String args[]) {

	int j;
	for ( j = 5;  j >  0; j-- )
	{
	  System.out.print( j + " " );
	}
	     System.out.println( );

	}
}
